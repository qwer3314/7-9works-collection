const state = {
    currentAlgo: null,
    autoTimer: null,
    logs: [],
    initialized: false,
    compareMode: false,
    compareAlgoA: null,
    compareAlgoB: null,
    compareTimer: null,
    compareData: null
};

const elements = {
    algoGrid: document.getElementById("algoGrid"),
    algoCategory: document.getElementById("algoCategory"),
    algoDifficulty: document.getElementById("algoDifficulty"),
    algoDescription: document.getElementById("algoDescription"),
    timeComplexity: document.getElementById("timeComplexity"),
    spaceComplexity: document.getElementById("spaceComplexity"),
    inputArea: document.getElementById("inputArea"),
    caseButtons: document.getElementById("caseButtons"),
    stepIndex: document.getElementById("stepIndex"),
    totalSteps: document.getElementById("totalSteps"),
    finishedTag: document.getElementById("finishedTag"),
    message: document.getElementById("message"),
    logList: document.getElementById("logList"),
    canvas: document.getElementById("visualCanvas"),
    speedRange: document.getElementById("speedRange"),
    speedValue: document.getElementById("speedValue"),
    visualPanel: document.getElementById("visualPanel"),
    comparePanel: document.getElementById("comparePanel"),
    algoASelect: document.getElementById("algoASelect"),
    algoBSelect: document.getElementById("algoBSelect"),
    algoAName: document.getElementById("algoAName"),
    algoBName: document.getElementById("algoBName"),
    canvasA: document.getElementById("canvasA"),
    canvasB: document.getElementById("canvasB"),
    stepsA: document.getElementById("stepsA"),
    stepsB: document.getElementById("stepsB")
};

async function fetchJson(url, options = {}) {
    const response = await fetch(url, {
        headers: { "Content-Type": "application/json" },
        credentials: "same-origin",
        ...options
    });
    const data = await response.json();
    if (data.code && data.code !== 200 && !data.snapshot) {
        throw new Error(data.message || "请求失败");
    }
    return data;
}

function setMessage(text, isError = true) {
    elements.message.textContent = text || "";
    elements.message.style.color = isError ? "#dc2626" : "#059669";
}

function parseInput(algoId, raw) {
    const text = raw.trim();
    if (!text) {
        throw new Error("请输入测试数据");
    }

    if (algoId === "quicksort" || algoId === "bubblesort") {
        const array = text.split(/[,，\s]+/).filter(Boolean).map(Number);
        if (array.some(Number.isNaN)) {
            throw new Error("排序输入必须是整数，例如 38,27,43,3,9");
        }
        if (array.length > 30) {
            throw new Error("数组长度不能超过30");
        }
        return { array };
    }

    if (algoId === "hanoi") {
        const disks = Number(text);
        if (!Number.isInteger(disks) || disks < 3 || disks > 8) {
            throw new Error("汉诺塔盘子数量必须是 3 到 8 的整数");
        }
        return { disks };
    }

    if (algoId === "huffman") {
        const frequencies = {};
        text.split(/[,，\s]+/).filter(Boolean).forEach(part => {
            const pair = part.split(":");
            if (pair.length !== 2) {
                throw new Error("哈夫曼输入格式应为 A:5,B:9,C:12");
            }
            const value = Number(pair[1]);
            if (Number.isNaN(value) || value < 1) {
                throw new Error("哈夫曼频率必须是正整数");
            }
            frequencies[pair[0].trim()] = value;
        });
        if (Object.keys(frequencies).length < 2) {
            throw new Error("哈夫曼编码至少需要2个字符");
        }
        return { frequencies };
    }

    try {
        const json = JSON.parse(text);
        if (!json.nodes || !json.edges || !json.source || !json.target) {
            throw new Error("Dijkstra输入必须包含 nodes, edges, source, target 字段");
        }
        if (!Array.isArray(json.nodes) || json.nodes.length < 2) {
            throw new Error("nodes 必须是至少包含2个节点的数组");
        }
        return json;
    } catch (error) {
        throw new Error("Dijkstra 输入必须是有效的 JSON");
    }
}

function defaultInputPlaceholder(algoId) {
    return {
        quicksort: "38,27,43,3,9,82,10",
        bubblesort: "38,27,43,3,9,82,10",
        dijkstra: JSON.stringify({
            nodes: ["A", "B", "C", "D", "E"],
            edges: [
                { from: "A", to: "B", weight: 6 },
                { from: "A", to: "C", weight: 1 },
                { from: "C", to: "B", weight: 2 },
                { from: "C", to: "D", weight: 2 },
                { from: "B", to: "D", weight: 3 },
                { from: "B", to: "E", weight: 5 },
                { from: "D", to: "E", weight: 2 }
            ],
            source: "A",
            target: "E"
        }, null, 2),
        hanoi: "3",
        huffman: "A:5,B:9,C:12,D:13,E:16,F:45"
    }[algoId] || "";
}

function renderAlgorithms(algorithms) {
    elements.algoGrid.innerHTML = algorithms.map(algo => `
        <article class="algo-card" data-algo="${algo.id}">
            <h3>${algo.name}</h3>
            <p>${algo.category} · 难度 ${algo.difficulty}</p>
        </article>
    `).join("");

    elements.algoGrid.querySelectorAll(".algo-card").forEach(card => {
        card.addEventListener("click", () => selectAlgorithm(card.dataset.algo));
    });
}

function populateCompareSelects(algorithms) {
    const html = algorithms.map(algo => `<option value="${algo.id}">${algo.name}</option>`).join("");
    elements.algoASelect.innerHTML = html;
    elements.algoBSelect.innerHTML = html;
    elements.algoASelect.value = "quicksort";
    elements.algoBSelect.value = "bubblesort";
}

async function selectAlgorithm(algoId) {
    stopAuto();
    state.currentAlgo = algoId;
    state.initialized = false;
    state.logs = [];
    renderLogs();

    document.querySelectorAll(".algo-card").forEach(card => {
        card.classList.toggle("active", card.dataset.algo === algoId);
    });

    const info = await fetchJson(`/api/${algoId}/info`);
    const payload = info.data;
    elements.algoCategory.textContent = payload.category;
    elements.algoDifficulty.textContent = `难度 ${payload.difficulty}`;
    elements.algoDescription.textContent = payload.description;
    elements.timeComplexity.textContent = payload.timeComplexity;
    elements.spaceComplexity.textContent = payload.spaceComplexity;
    elements.inputArea.value = defaultInputPlaceholder(algoId);
    elements.inputArea.placeholder = payload.inputHint;
    setMessage("");

    const cases = await fetchJson(`/api/${algoId}/cases`);
    elements.caseButtons.innerHTML = cases.data.map(testCase => `
        <button class="btn secondary case-btn" data-case-id="${testCase.id}" title="${testCase.description}">
            ${testCase.name}
        </button>
    `).join("");

    elements.caseButtons.querySelectorAll(".case-btn").forEach(button => {
        button.addEventListener("click", () => initAlgorithm({ caseId: button.dataset.caseId }));
    });

    clearCanvas(elements.canvas);
    elements.stepIndex.textContent = "0";
    elements.totalSteps.textContent = "0";
    elements.finishedTag.textContent = "未开始";
}

function renderLogs(activeLog) {
    elements.logList.innerHTML = state.logs.map(log => `
        <div class="log-item ${log === activeLog ? "active" : ""}">${log}</div>
    `).join("");
    elements.logList.scrollTop = elements.logList.scrollHeight;
}

function applySnapshot(snapshot) {
    if (!snapshot) {
        return;
    }
    elements.stepIndex.textContent = String((snapshot.stepIndex ?? 0) + 1);
    elements.totalSteps.textContent = String(snapshot.totalSteps ?? 0);
    elements.finishedTag.textContent = snapshot.finished ? "已完成" : "执行中";
    
    const displayTime = snapshot.actualTimeComplexity || snapshot.timeComplexity || elements.timeComplexity.textContent;
    const displaySpace = snapshot.actualSpaceComplexity || snapshot.spaceComplexity || elements.spaceComplexity.textContent;
    elements.timeComplexity.textContent = displayTime;
    elements.spaceComplexity.textContent = displaySpace;

    if (snapshot.log) {
        state.logs.push(snapshot.log);
        renderLogs(snapshot.log);
    }

    Renderers.draw(state.currentAlgo, elements.canvas, snapshot.snapshot || {});
}

async function initAlgorithm(extra = {}) {
    if (!state.currentAlgo) {
        setMessage("请先选择算法");
        return;
    }

    try {
        stopAuto();
        const body = { ...extra };
        if (!body.caseId) {
            body.data = parseInput(state.currentAlgo, elements.inputArea.value);
        }

        const snapshot = await fetchJson(`/api/${state.currentAlgo}/init`, {
            method: "POST",
            body: JSON.stringify(body)
        });

        state.initialized = true;
        state.logs = [];
        setMessage("初始化成功，可开始单步或连续执行", false);
        applySnapshot(snapshot);
    } catch (error) {
        setMessage(error.message);
    }
}

async function stepAlgorithm() {
    if (!state.initialized) {
        setMessage("请先初始化算法数据");
        return;
    }

    try {
        const snapshot = await fetchJson(`/api/${state.currentAlgo}/step`, { method: "POST" });
        applySnapshot(snapshot);
        if (snapshot.finished) {
            stopAuto();
        }
        setMessage("");
    } catch (error) {
        setMessage(error.message);
        stopAuto();
    }
}

async function prevAlgorithm() {
    if (!state.initialized) {
        setMessage("请先初始化算法数据");
        return;
    }

    try {
        const response = await fetch(`/api/${state.currentAlgo}/prev`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            credentials: "same-origin"
        });
        const snapshot = await response.json();
        state.logs.pop();
        renderLogs();
        applySnapshot(snapshot);
        setMessage("");
    } catch (error) {
        setMessage(error.message);
    }
}

async function resetAlgorithm() {
    if (!state.currentAlgo) {
        return;
    }
    stopAuto();
    try {
        await fetchJson(`/api/${state.currentAlgo}/reset`);
        state.initialized = false;
        state.logs = [];
        renderLogs();
        clearCanvas(elements.canvas);
        elements.stepIndex.textContent = "0";
        elements.totalSteps.textContent = "0";
        elements.finishedTag.textContent = "已重置";
        setMessage("已重置，请重新初始化", false);
    } catch (error) {
        setMessage(error.message);
    }
}

async function exportLogs() {
    if (!state.currentAlgo || !state.initialized) {
        setMessage("请先初始化并执行算法");
        return;
    }

    try {
        const result = await fetchJson(`/api/${state.currentAlgo}/export`);
        const logs = result.data;
        const content = logs.map((log, index) => `${index + 1}. ${log}`).join("\n");
        const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `${state.currentAlgo}_logs_${new Date().toISOString().slice(0, 19).replace(/:/g, "-")}.txt`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        setMessage("日志导出成功", false);
    } catch (error) {
        setMessage(error.message);
    }
}

function startAuto() {
    if (!state.initialized) {
        setMessage("请先初始化算法数据");
        return;
    }
    stopAuto();
    const interval = Number(elements.speedRange.value);
    state.autoTimer = setInterval(stepAlgorithm, interval);
}

function stopAuto() {
    if (state.autoTimer) {
        clearInterval(state.autoTimer);
        state.autoTimer = null;
    }
}

function clearCanvas(canvas) {
    const ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "#64748b";
    ctx.font = "18px sans-serif";
    ctx.fillText("等待初始化...", canvas.width / 2 - 80, canvas.height / 2);
}

async function loadRandomInput() {
    if (!state.currentAlgo) {
        setMessage("请先选择算法");
        return;
    }
    const result = await fetchJson(`/api/${state.currentAlgo}/random`);
    const data = result.data;
    if (state.currentAlgo === "quicksort" || state.currentAlgo === "bubblesort") {
        elements.inputArea.value = data.array.join(",");
    } else if (state.currentAlgo === "hanoi") {
        elements.inputArea.value = String(data.disks);
    } else if (state.currentAlgo === "huffman") {
        elements.inputArea.value = Object.entries(data.frequencies).map(([k, v]) => `${k}:${v}`).join(",");
    } else {
        elements.inputArea.value = JSON.stringify(data, null, 2);
    }
    setMessage("已生成随机测试数据", false);
}

async function toggleCompareMode() {
    state.compareMode = !state.compareMode;
    
    if (state.compareMode) {
        stopAuto();
        elements.visualPanel.style.display = "none";
        elements.comparePanel.style.display = "block";
        
        const result = await fetchJson("/api/algorithms");
        populateCompareSelects(result.data);
        
        elements.algoASelect.addEventListener("change", updateAlgoNames);
        elements.algoBSelect.addEventListener("change", updateAlgoNames);
        updateAlgoNames();
        
        clearCanvas(elements.canvasA);
        clearCanvas(elements.canvasB);
        elements.stepsA.textContent = "0";
        elements.stepsB.textContent = "0";
    } else {
        stopCompareAuto();
        elements.visualPanel.style.display = "block";
        elements.comparePanel.style.display = "none";
        
        if (state.currentAlgo) {
            clearCanvas(elements.canvas);
        }
    }
}

function updateAlgoNames() {
    state.compareAlgoA = elements.algoASelect.value;
    state.compareAlgoB = elements.algoBSelect.value;
    
    fetchJson(`/api/${state.compareAlgoA}/info`).then(data => {
        elements.algoAName.textContent = data.data.name;
    });
    fetchJson(`/api/${state.compareAlgoB}/info`).then(data => {
        elements.algoBName.textContent = data.data.name;
    });
}

async function initCompare() {
    const algoA = state.compareAlgoA;
    const algoB = state.compareAlgoB;
    
    if (!algoA || !algoB) {
        setMessage("请选择两个算法进行对比");
        return;
    }

    try {
        const rawInput = elements.inputArea.value.trim();
        if (!rawInput) {
            setMessage("请先输入测试数据");
            return;
        }

        const data = parseInput(algoA, rawInput);
        state.compareData = data;

        const snapshotA = await fetchJson(`/api/${algoA}/init`, {
            method: "POST",
            body: JSON.stringify({ data })
        });
        
        const snapshotB = await fetchJson(`/api/${algoB}/init`, {
            method: "POST",
            body: JSON.stringify({ data })
        });

        Renderers.draw(algoA, elements.canvasA, snapshotA.snapshot || {});
        Renderers.draw(algoB, elements.canvasB, snapshotB.snapshot || {});
        elements.stepsA.textContent = String((snapshotA.stepIndex ?? 0) + 1);
        elements.stepsB.textContent = String((snapshotB.stepIndex ?? 0) + 1);
        
        setMessage("对比初始化成功", false);
    } catch (error) {
        setMessage(error.message);
    }
}

async function compareStep() {
    const algoA = state.compareAlgoA;
    const algoB = state.compareAlgoB;
    
    if (!algoA || !algoB) {
        setMessage("请先初始化对比");
        return;
    }

    try {
        const snapshotA = await fetchJson(`/api/${algoA}/step`, { method: "POST" });
        const snapshotB = await fetchJson(`/api/${algoB}/step`, { method: "POST" });

        Renderers.draw(algoA, elements.canvasA, snapshotA.snapshot || {});
        Renderers.draw(algoB, elements.canvasB, snapshotB.snapshot || {});
        
        elements.stepsA.textContent = String((snapshotA.stepIndex ?? 0) + 1);
        elements.stepsB.textContent = String((snapshotB.stepIndex ?? 0) + 1);
        
        if (snapshotA.finished && snapshotB.finished) {
            stopCompareAuto();
            setMessage("对比完成", false);
        }
    } catch (error) {
        setMessage(error.message);
        stopCompareAuto();
    }
}

function startCompareAuto() {
    stopCompareAuto();
    const interval = Number(elements.speedRange.value);
    state.compareTimer = setInterval(compareStep, interval);
}

function stopCompareAuto() {
    if (state.compareTimer) {
        clearInterval(state.compareTimer);
        state.compareTimer = null;
    }
}

async function resetCompare() {
    stopCompareAuto();
    clearCanvas(elements.canvasA);
    clearCanvas(elements.canvasB);
    elements.stepsA.textContent = "0";
    elements.stepsB.textContent = "0";
    setMessage("对比已重置，请重新初始化", false);
}

function saveCustomTestCase() {
    const algoId = state.currentAlgo;
    if (!algoId) {
        setMessage("请先选择算法");
        return;
    }

    const data = elements.inputArea.value.trim();
    if (!data) {
        setMessage("请先输入测试数据");
        return;
    }

    try {
        parseInput(algoId, data);
        const savedCases = JSON.parse(localStorage.getItem("customTestCases") || "{}");
        if (!savedCases[algoId]) {
            savedCases[algoId] = [];
        }
        
        savedCases[algoId].push({
            id: `custom-${Date.now()}`,
            name: `自定义用例 ${savedCases[algoId].length + 1}`,
            description: "用户自定义测试数据",
            data: data,
            savedAt: new Date().toISOString()
        });
        
        localStorage.setItem("customTestCases", JSON.stringify(savedCases));
        setMessage("测试数据保存成功", false);
    } catch (error) {
        setMessage(error.message);
    }
}

document.getElementById("initBtn").addEventListener("click", () => {
    if (state.compareMode) {
        initCompare();
    } else {
        initAlgorithm();
    }
});
document.getElementById("stepBtn").addEventListener("click", stepAlgorithm);
document.getElementById("prevBtn").addEventListener("click", prevAlgorithm);
document.getElementById("autoBtn").addEventListener("click", startAuto);
document.getElementById("pauseBtn").addEventListener("click", stopAuto);
document.getElementById("resetBtn").addEventListener("click", resetAlgorithm);
document.getElementById("exportBtn").addEventListener("click", exportLogs);
document.getElementById("randomBtn").addEventListener("click", loadRandomInput);
document.getElementById("compareModeBtn").addEventListener("click", toggleCompareMode);
document.getElementById("compareStepBtn").addEventListener("click", compareStep);
document.getElementById("compareAutoBtn").addEventListener("click", startCompareAuto);
document.getElementById("comparePauseBtn").addEventListener("click", stopCompareAuto);
document.getElementById("compareResetBtn").addEventListener("click", resetCompare);
document.getElementById("exitCompareBtn").addEventListener("click", toggleCompareMode);

elements.speedRange.addEventListener("input", () => {
    elements.speedValue.textContent = elements.speedRange.value;
    if (state.autoTimer) {
        startAuto();
    }
});

async function bootstrap() {
    clearCanvas(elements.canvas);
    const result = await fetchJson("/api/algorithms");
    renderAlgorithms(result.data);
    if (result.data.length > 0) {
        await selectAlgorithm(result.data[0].id);
    }
}

bootstrap().catch(error => setMessage(error.message));