const Renderers = {
    draw(algoId, canvas, snapshot) {
        const ctx = canvas.getContext("2d");
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        switch (algoId) {
            case "quicksort":
                this.drawQuickSort(ctx, canvas, snapshot);
                break;
            case "bubblesort":
                this.drawBubbleSort(ctx, canvas, snapshot);
                break;
            case "dijkstra":
                this.drawDijkstra(ctx, canvas, snapshot);
                break;
            case "hanoi":
                this.drawHanoi(ctx, canvas, snapshot);
                break;
            case "huffman":
                this.drawHuffman(ctx, canvas, snapshot);
                break;
            default:
                ctx.fillStyle = "#64748b";
                ctx.fillText("暂不支持的可视化类型", 360, 260);
        }
    },

    drawQuickSort(ctx, canvas, snapshot) {
        const array = snapshot.array || [];
        if (array.length === 0) {
            return;
        }

        const barWidth = Math.min(60, (canvas.width - 80) / array.length);
        const gap = 12;
        const maxValue = Math.max(...array, 1);
        const baseY = canvas.height - 60;

        array.forEach((value, index) => {
            const height = (value / maxValue) * (canvas.height - 140);
            const x = 40 + index * (barWidth + gap);
            const y = baseY - height;
            const highlights = snapshot.highlights || [];
            const isPivot = index === snapshot.pivot;
            const isActive = highlights.includes(index);

            ctx.fillStyle = isPivot ? "#f97316" : isActive ? "#2563eb" : "#93c5fd";
            ctx.fillRect(x, y, barWidth, height);

            ctx.fillStyle = "#1f2937";
            ctx.font = "14px sans-serif";
            ctx.textAlign = "center";
            ctx.fillText(String(value), x + barWidth / 2, y - 8);
            ctx.fillText(`[${index}]`, x + barWidth / 2, baseY + 20);
        });
    },

    drawBubbleSort(ctx, canvas, snapshot) {
        const array = snapshot.array || [];
        if (array.length === 0) {
            return;
        }

        const barWidth = Math.min(60, (canvas.width - 80) / array.length);
        const gap = 12;
        const maxValue = Math.max(...array, 1);
        const baseY = canvas.height - 60;
        const pass = snapshot.pass;

        array.forEach((value, index) => {
            const height = (value / maxValue) * (canvas.height - 140);
            const x = 40 + index * (barWidth + gap);
            const y = baseY - height;
            const isActive = index === snapshot.active;
            const isSecondary = index === snapshot.secondary;
            const isSorted = pass >= 0 && index > array.length - 2 - pass;

            let color = "#93c5fd";
            if (isActive) {
                color = "#2563eb";
            } else if (isSecondary) {
                color = "#3b82f6";
            } else if (isSorted) {
                color = "#86efac";
            }
            
            ctx.fillStyle = color;
            ctx.fillRect(x, y, barWidth, height);

            ctx.fillStyle = "#1f2937";
            ctx.font = "14px sans-serif";
            ctx.textAlign = "center";
            ctx.fillText(String(value), x + barWidth / 2, y - 8);
            ctx.fillText(`[${index}]`, x + barWidth / 2, baseY + 20);
        });

        if (pass >= 0) {
            ctx.fillStyle = "#64748b";
            ctx.font = "12px sans-serif";
            ctx.textAlign = "left";
            ctx.fillText(`第 ${pass + 1} 轮排序`, 20, 25);
        }
    },

    drawDijkstra(ctx, canvas, snapshot) {
        const nodes = snapshot.nodes || [];
        const edges = snapshot.edges || [];
        const positions = this.layoutNodes(nodes, canvas);
        const settled = new Set(snapshot.settled || []);
        const path = snapshot.path || [];
        const pathSet = new Set(path);
        const activeEdge = snapshot.activeEdge;

        edges.forEach(edge => {
            const from = positions[edge.from];
            const to = positions[edge.to];
            if (!from || !to) {
                return;
            }
            const isActive = activeEdge && activeEdge.from === edge.from && activeEdge.to === edge.to;
            ctx.beginPath();
            ctx.moveTo(from.x, from.y);
            ctx.lineTo(to.x, to.y);
            ctx.strokeStyle = isActive ? "#dc2626" : "#94a3b8";
            ctx.lineWidth = isActive ? 3 : 2;
            ctx.stroke();

            const midX = (from.x + to.x) / 2;
            const midY = (from.y + to.y) / 2;
            ctx.fillStyle = "#334155";
            ctx.font = "13px sans-serif";
            ctx.fillText(String(edge.weight), midX, midY - 6);
        });

        nodes.forEach(node => {
            const point = positions[node];
            if (!point) {
                return;
            }
            const isActive = node === snapshot.active;
            const isSettled = settled.has(node);
            const inPath = pathSet.has(node);

            ctx.beginPath();
            ctx.arc(point.x, point.y, 24, 0, Math.PI * 2);
            ctx.fillStyle = inPath ? "#16a34a" : isActive ? "#2563eb" : isSettled ? "#bfdbfe" : "#e2e8f0";
            ctx.fill();
            ctx.strokeStyle = "#1e293b";
            ctx.stroke();

            ctx.fillStyle = "#111827";
            ctx.textAlign = "center";
            ctx.font = "bold 14px sans-serif";
            ctx.fillText(node, point.x, point.y + 5);

            const dist = snapshot.distances ? snapshot.distances[node] : "-";
            ctx.font = "12px sans-serif";
            ctx.fillText(`dist=${dist}`, point.x, point.y + 38);
        });
    },

    layoutNodes(nodes, canvas) {
        const positions = {};
        const centerX = canvas.width / 2;
        const centerY = canvas.height / 2;
        const radius = Math.min(canvas.width, canvas.height) / 3;
        nodes.forEach((node, index) => {
            const angle = (Math.PI * 2 * index) / nodes.length - Math.PI / 2;
            positions[node] = {
                x: centerX + radius * Math.cos(angle),
                y: centerY + radius * Math.sin(angle)
            };
        });
        return positions;
    },

    drawHanoi(ctx, canvas, snapshot) {
        const rods = snapshot.rods || [[], [], []];
        const names = snapshot.rodNames || ["A", "B", "C"];
        const rodWidth = 16;
        const baseY = canvas.height - 80;
        const spacing = canvas.width / 4;

        rods.forEach((rod, index) => {
            const x = spacing * (index + 1);
            ctx.fillStyle = "#475569";
            ctx.fillRect(x - rodWidth / 2, baseY - 220, rodWidth, 220);
            ctx.fillRect(x - 110, baseY, 220, 16);

            ctx.fillStyle = "#0f172a";
            ctx.font = "bold 16px sans-serif";
            ctx.textAlign = "center";
            ctx.fillText(names[index], x, baseY + 36);

            rod.forEach((diskSize, level) => {
                const width = 40 + diskSize * 24;
                const height = 22;
                const y = baseY - 20 - (level + 1) * (height + 6);
                const moving = snapshot.movingDisk === diskSize
                    && (snapshot.fromRod === index || snapshot.toRod === index);
                ctx.fillStyle = moving ? "#f97316" : "#38bdf8";
                ctx.fillRect(x - width / 2, y, width, height);
                ctx.fillStyle = "#0f172a";
                ctx.fillText(String(diskSize), x, y + 16);
            });
        });
    },

    drawHuffman(ctx, canvas, snapshot) {
        if (snapshot.tree) {
            this.drawTreeNode(ctx, snapshot.tree, canvas.width / 2, 40, canvas.width / 4);
            this.drawCodes(ctx, canvas, snapshot.codes || {});
            return;
        }

        const forest = snapshot.forest || [];
        const startX = 80;
        const gap = Math.min(120, (canvas.width - 160) / Math.max(forest.length, 1));
        forest.forEach((node, index) => {
            const x = startX + index * gap;
            const y = 180;
            const highlight = node.id === snapshot.highlightA || node.id === snapshot.highlightB;
            ctx.beginPath();
            ctx.arc(x, y, 34, 0, Math.PI * 2);
            ctx.fillStyle = highlight ? "#fb7185" : "#c4b5fd";
            ctx.fill();
            ctx.strokeStyle = "#312e81";
            ctx.stroke();
            ctx.fillStyle = "#111827";
            ctx.textAlign = "center";
            ctx.font = "13px sans-serif";
            ctx.fillText(node.label, x, y + 4);
            ctx.fillText(String(node.frequency), x, y + 52);
        });
    },

    drawTreeNode(ctx, node, x, y, offset) {
        if (!node) {
            return;
        }

        ctx.beginPath();
        ctx.arc(x, y, 28, 0, Math.PI * 2);
        ctx.fillStyle = node.left || node.right ? "#fde68a" : "#86efac";
        ctx.fill();
        ctx.strokeStyle = "#334155";
        ctx.stroke();

        ctx.fillStyle = "#111827";
        ctx.textAlign = "center";
        ctx.font = "12px sans-serif";
        ctx.fillText(node.label, x, y + 4);
        ctx.fillText(String(node.frequency), x, y + 46);

        if (node.left) {
            ctx.beginPath();
            ctx.moveTo(x, y + 28);
            ctx.lineTo(x - offset, y + 80);
            ctx.strokeStyle = "#64748b";
            ctx.stroke();
            this.drawTreeNode(ctx, node.left, x - offset, y + 110, offset / 1.8);
        }

        if (node.right) {
            ctx.beginPath();
            ctx.moveTo(x, y + 28);
            ctx.lineTo(x + offset, y + 80);
            ctx.strokeStyle = "#64748b";
            ctx.stroke();
            this.drawTreeNode(ctx, node.right, x + offset, y + 110, offset / 1.8);
        }
    },

    drawCodes(ctx, canvas, codes) {
        const entries = Object.entries(codes);
        let y = canvas.height - 40 - entries.length * 18;
        ctx.textAlign = "left";
        ctx.font = "14px sans-serif";
        entries.forEach(([symbol, code]) => {
            ctx.fillStyle = "#111827";
            ctx.fillText(`${symbol}: ${code}`, 40, y);
            y += 18;
        });
    }
};
