package com.algo.visualizer.context;

import com.algo.visualizer.model.AlgorithmInfo;
import com.algo.visualizer.model.TestCase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class BubbleSortContext extends AbstractAlgorithmContext {

    private int inputSize;

    public BubbleSortContext() {
        super(new AlgorithmInfo(
                "bubblesort",
                "冒泡排序",
                "排序",
                "易",
                "重复遍历数组，比较相邻元素并交换位置，使较大元素逐步\"冒泡\"到数组末端。",
                "O(n²)",
                "O(1)",
                "输入整数数组，例如：38,27,43,3,9,82,10"
        ));
    }

    @Override
    public List<TestCase> getTestCases() {
        List<TestCase> cases = new ArrayList<>();
        cases.add(new TestCase(
                "bs-case-1",
                "经典乱序",
                "常见教学示例，包含重复与跨度较大的数值。",
                Map.of("array", List.of(38, 27, 43, 3, 9, 82, 10))
        ));
        cases.add(new TestCase(
                "bs-case-2",
                "近乎有序",
                "仅末尾两个元素需要交换，便于观察优化效果。",
                Map.of("array", List.of(1, 2, 3, 4, 5, 7, 6))
        ));
        return cases;
    }

    @Override
    protected void buildSteps(Map<String, Object> input) {
        int[] array = toIntArray(input.get("array"));
        this.inputSize = array.length;
        if (array.length == 0) {
            throw new IllegalArgumentException("数组不能为空");
        }
        if (array.length > 30) {
            throw new IllegalArgumentException("数组长度不能超过 30");
        }

        addStep("初始化：准备对数组执行冒泡排序", snapshot(array, -1, -1, -1, List.of()));
        
        int n = array.length;
        for (int i = 0; i < n - 1; i++) {
            addStep("第 " + (i + 1) + " 轮排序开始，需要比较 " + (n - 1 - i) + " 次", 
                    snapshot(array, -1, -1, i, List.of()));

            boolean swapped = false;
            for (int j = 0; j < n - 1 - i; j++) {
                addStep("比较 arr[" + j + "]=" + array[j] + " 与 arr[" + (j + 1) + "]=" + array[j + 1],
                        snapshot(array, j, j + 1, i, List.of(j, j + 1)));
                
                if (array[j] > array[j + 1]) {
                    swap(array, j, j + 1);
                    swapped = true;
                    addStep("交换 arr[" + j + "] 与 arr[" + (j + 1) + "]",
                            snapshot(array, j, j + 1, i, List.of(j, j + 1)));
                } else {
                    addStep("无需交换，arr[" + j + "] <= arr[" + (j + 1) + "]",
                            snapshot(array, j, j + 1, i, List.of(j, j + 1)));
                }
            }
            
            if (!swapped) {
                addStep("本轮无交换，数组已有序，提前结束", snapshot(array, -1, -1, i, List.of()));
                break;
            }
            
            addStep("第 " + (i + 1) + " 轮排序结束，最大元素已冒泡到位置 " + (n - 1 - i),
                    snapshot(array, n - 1 - i, -1, i, List.of(n - 1 - i)));
        }
        
        addStep("排序完成：所有元素已按升序排列", snapshot(array, -1, -1, -1, List.of()));
    }

    @Override
    protected int getInputSize() {
        return inputSize;
    }

    private void swap(int[] array, int i, int j) {
        int temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }

    private Map<String, Object> snapshot(int[] array, int active, int secondary, int pass, List<Integer> highlights) {
        Map<String, Object> map = new HashMap<>();
        map.put("array", toList(array));
        map.put("active", active);
        map.put("secondary", secondary);
        map.put("pass", pass);
        map.put("highlights", highlights);
        return map;
    }

    public static Map<String, Object> randomInput() {
        Random random = new Random();
        int size = 6 + random.nextInt(7);
        List<Integer> values = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            values.add(1 + random.nextInt(99));
        }
        return Map.of("array", values);
    }

    private int[] toIntArray(Object raw) {
        if (raw instanceof List<?> list) {
            int[] array = new int[list.size()];
            for (int i = 0; i < list.size(); i++) {
                array[i] = ((Number) list.get(i)).intValue();
            }
            return array;
        }
        throw new IllegalArgumentException("array 字段必须是整数数组");
    }

    private List<Integer> toList(int[] array) {
        List<Integer> list = new ArrayList<>();
        for (int value : array) {
            list.add(value);
        }
        return list;
    }
}