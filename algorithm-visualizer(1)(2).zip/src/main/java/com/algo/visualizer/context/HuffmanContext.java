package com.algo.visualizer.context;

import com.algo.visualizer.model.AlgorithmInfo;
import com.algo.visualizer.model.TestCase;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Random;

public class HuffmanContext extends AbstractAlgorithmContext {

    public HuffmanContext() {
        super(new AlgorithmInfo(
                "huffman",
                "哈夫曼树构造",
                "树结构",
                "中",
                "每次选择频率最小的两个节点合并，直到只剩一棵树，用于构造最优前缀编码。",
                "O(n log n)",
                "O(n)",
                "输入字符频率，例如：A:5,B:9,C:12,D:13,E:16,F:45"
        ));
    }

    @Override
    public List<TestCase> getTestCases() {
        List<TestCase> cases = new ArrayList<>();
        cases.add(new TestCase(
                "hf-case-1",
                "经典六字符",
                "教材常见频率分布。",
                Map.of("frequencies", mapOf(
                        "A", 5, "B", 9, "C", 12, "D", 13, "E", 16, "F", 45
                ))
        ));
        cases.add(new TestCase(
                "hf-case-2",
                "四字符合并",
                "节点较少，便于逐步观察合并过程。",
                Map.of("frequencies", mapOf(
                        "X", 2, "Y", 3, "Z", 7, "W", 9
                ))
        ));
        return cases;
    }

    @Override
    protected void buildSteps(Map<String, Object> input) {
        Map<String, Integer> frequencies = parseFrequencies(input.get("frequencies"));
        if (frequencies.size() < 2) {
            throw new IllegalArgumentException("至少需要 2 个字符频率");
        }
        if (frequencies.size() > 10) {
            throw new IllegalArgumentException("字符数量不能超过 10");
        }

        PriorityQueue<HuffmanNode> queue = new PriorityQueue<>(Comparator.comparingInt(n -> n.frequency));
        int idCounter = 0;
        for (Map.Entry<String, Integer> entry : frequencies.entrySet()) {
            queue.add(new HuffmanNode("leaf-" + idCounter++, entry.getKey(), entry.getValue(), null, null));
        }

        List<HuffmanNode> forest = new ArrayList<>(queue);
        addStep("初始化：为每个字符创建叶子节点", forestSnapshot(forest, null, null));

        while (queue.size() > 1) {
            HuffmanNode first = queue.poll();
            HuffmanNode second = queue.poll();
            HuffmanNode merged = new HuffmanNode(
                    "node-" + idCounter++,
                    first.chars + second.chars,
                    first.frequency + second.frequency,
                    first,
                    second
            );
            addStep("选择频率最小的两个节点 [" + first.chars + ":" + first.frequency + "] 与 [" + second.chars + ":" + second.frequency + "] 进行合并",
                    forestSnapshot(new ArrayList<>(queue), first, second));

            queue.add(merged);
            forest = new ArrayList<>(queue);
            addStep("合并得到新节点 [" + merged.symbol + "]，频率 = " + merged.frequency,
                    forestSnapshot(forest, merged, null));
        }

        HuffmanNode root = queue.peek();
        Map<String, String> codes = new HashMap<>();
        buildCodes(root, "", codes);
        addStep("构造完成：哈夫曼树已建立，可得到最优前缀编码", finalSnapshot(root, codes));
    }

    private void buildCodes(HuffmanNode node, String prefix, Map<String, String> codes) {
        if (node == null) {
            return;
        }
        if (node.left == null && node.right == null) {
            codes.put(node.chars, prefix.isEmpty() ? "0" : prefix);
            return;
        }
        buildCodes(node.left, prefix + "0", codes);
        buildCodes(node.right, prefix + "1", codes);
    }

    private Map<String, Object> forestSnapshot(List<HuffmanNode> forest, HuffmanNode highlightA, HuffmanNode highlightB) {
        Map<String, Object> map = new HashMap<>();
        map.put("forest", forest.stream().map(HuffmanNode::toMap).toList());
        map.put("highlightA", highlightA == null ? null : highlightA.id);
        map.put("highlightB", highlightB == null ? null : highlightB.id);
        map.put("tree", null);
        map.put("codes", Map.of());
        return map;
    }

    private Map<String, Object> finalSnapshot(HuffmanNode root, Map<String, String> codes) {
        Map<String, Object> map = new HashMap<>();
        map.put("forest", List.of());
        map.put("highlightA", null);
        map.put("highlightB", null);
        map.put("tree", root.toMap());
        map.put("codes", codes);
        return map;
    }

    private Map<String, Integer> parseFrequencies(Object raw) {
        if (raw instanceof Map<?, ?> map) {
            Map<String, Integer> result = new LinkedHashMap<>();
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                result.put(String.valueOf(entry.getKey()), ((Number) entry.getValue()).intValue());
            }
            return result;
        }
        throw new IllegalArgumentException("frequencies 格式错误");
    }

    public static Map<String, Object> randomInput() {
        Random random = new Random();
        String chars = "ABCDEFGH";
        Map<String, Integer> frequencies = new LinkedHashMap<>();
        int count = 4 + random.nextInt(3);
        for (int i = 0; i < count; i++) {
            frequencies.put(String.valueOf(chars.charAt(i)), 1 + random.nextInt(20));
        }
        return Map.of("frequencies", frequencies);
    }

    private static Map<String, Integer> mapOf(Object... pairs) {
        Map<String, Integer> map = new LinkedHashMap<>();
        for (int i = 0; i < pairs.length; i += 2) {
            map.put(String.valueOf(pairs[i]), ((Number) pairs[i + 1]).intValue());
        }
        return map;
    }

    private static class HuffmanNode {
        public final String id;
        public final String chars;
        public final int frequency;
        public final HuffmanNode left;
        public final HuffmanNode right;

        public HuffmanNode first;
        public HuffmanNode second;
        public Character symbol;
        public boolean merged;

        private HuffmanNode(String id, String chars, int frequency, HuffmanNode left, HuffmanNode right) {
            this.id = id;
            this.chars = chars;
            this.frequency = frequency;
            this.left = left;
            this.right = right;

            this.first = left;
            this.second = right;
            if(chars.length() == 1) this.symbol = chars.charAt(0);
            this.merged = left != null && right != null;
        }

        private Map<String, Object> toMap() {
            Map<String, Object> map = new HashMap<>();
            map.put("id", id);
            map.put("label", chars);
            map.put("frequency", frequency);
            map.put("left", left == null ? null : left.toMap());
            map.put("right", right == null ? null : right.toMap());
            return map;
        }
    }
}
