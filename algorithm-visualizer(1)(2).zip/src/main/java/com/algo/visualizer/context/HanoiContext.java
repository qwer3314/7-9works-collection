package com.algo.visualizer.context;

import com.algo.visualizer.model.AlgorithmInfo;
import com.algo.visualizer.model.TestCase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class HanoiContext extends AbstractAlgorithmContext {

    public HanoiContext() {
        super(new AlgorithmInfo(
                "hanoi",
                "汉诺塔",
                "递归",
                "中高",
                "将 n 个盘子从源柱借助辅助柱移动到目标柱，每次只允许移动最顶部的盘子，且大盘不能放在小盘上面。",
                "O(2^n)",
                "O(n)",
                "输入盘子数量 n（3-8）"
        ));
    }

    @Override
    public List<TestCase> getTestCases() {
        List<TestCase> cases = new ArrayList<>();
        cases.add(new TestCase(
                "hn-case-1",
                "三盘经典",
                "最少 7 步的标准汉诺塔演示。",
                Map.of("disks", 3)
        ));
        cases.add(new TestCase(
                "hn-case-2",
                "四盘进阶",
                "步数增加到 15 步，适合观察递归分治过程。",
                Map.of("disks", 4)
        ));
        return cases;
    }

    @Override
    protected void buildSteps(Map<String, Object> input) {
        int disks = ((Number) input.get("disks")).intValue();
        if (disks < 3 || disks > 8) {
            throw new IllegalArgumentException("盘子数量必须在 3 到 8 之间");
        }

        List<List<Integer>> rods = new ArrayList<>();
        rods.add(buildRod(disks));
        rods.add(new ArrayList<>());
        rods.add(new ArrayList<>());
        addStep("初始化：将 " + disks + " 个盘子放在 A 柱", hanoiSnapshot(rods, -1, -1, null));

        generateMoves(disks, 0, 2, 1, rods);
        addStep("完成：所有盘子已移动到 C 柱", hanoiSnapshot(rods, -1, -1, null));
    }

    private List<Integer> buildRod(int disks) {
        List<Integer> rod = new ArrayList<>();
        for (int size = disks; size >= 1; size--) {
            rod.add(size);
        }
        return new ArrayList<>(rod);
    }

    private void generateMoves(int count, int from, int to, int aux, List<List<Integer>> rods) {
        if (count == 1) {
            move(rods, from, to, "移动盘子 1 从 " + rodName(from) + " 到 " + rodName(to));
            return;
        }
        generateMoves(count - 1, from, aux, to, rods);
        move(rods, from, to, "移动盘子 " + count + " 从 " + rodName(from) + " 到 " + rodName(to));
        generateMoves(count - 1, aux, to, from, rods);
    }

    private void move(List<List<Integer>> rods, int from, int to, String log) {
        int disk = rods.get(from).remove(rods.get(from).size() - 1);
        rods.get(to).add(disk);
        addStep(log, hanoiSnapshot(deepCopy(rods), from, to, disk));
    }

    private Map<String, Object> hanoiSnapshot(List<List<Integer>> rods, int from, int to, Integer disk) {
        Map<String, Object> map = new HashMap<>();
        map.put("rods", deepCopy(rods));
        map.put("fromRod", from);
        map.put("toRod", to);
        map.put("movingDisk", disk);
        map.put("rodNames", List.of("A", "B", "C"));
        return map;
    }

    private List<List<Integer>> deepCopy(List<List<Integer>> rods) {
        List<List<Integer>> copy = new ArrayList<>();
        for (List<Integer> rod : rods) {
            copy.add(new ArrayList<>(rod));
        }
        return copy;
    }

    private String rodName(int index) {
        return switch (index) {
            case 0 -> "A";
            case 1 -> "B";
            default -> "C";
        };
    }

    public static Map<String, Object> randomInput() {
        Random random = new Random();
        return Map.of("disks", 3 + random.nextInt(3));
    }

}
