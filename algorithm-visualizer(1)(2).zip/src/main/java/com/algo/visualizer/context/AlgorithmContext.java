package com.algo.visualizer.context;

import com.algo.visualizer.model.AlgorithmInfo;
import com.algo.visualizer.model.StepSnapshot;
import com.algo.visualizer.model.TestCase;

import java.util.List;
import java.util.Map;

public interface AlgorithmContext {

    String getId();

    AlgorithmInfo getInfo();

    List<TestCase> getTestCases();

    void initialize(Map<String, Object> input);

    StepSnapshot step();

    StepSnapshot prev();

    StepSnapshot getCurrentSnapshot();

    void reset();

    boolean isInitialized();

    boolean isFinished();

    List<String> getLogs();
}
