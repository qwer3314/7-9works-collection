package com.algo.visualizer.context;

import com.algo.visualizer.model.AlgorithmInfo;
import com.algo.visualizer.model.TestCase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class QuickSortContext extends AbstractAlgorithmContext {

    private int inputSize;

    public QuickSortContext() {
        super(new AlgorithmInfo(
                "quicksort",
                "快速排序",
                "排序",
                "中",
                "选取基准元素，通过分区将较小元素移到左侧，较大元素移到右侧，再递归处理子区间。",
                "平均 O(n log n)，最坏 O(n²)",
                "O(log n)",
                "输入整数数组，例如：38,27,43,3,9,82,10"
        ));
    }

    @Override
    public List<TestCase> getTestCases() {
        List<TestCase> cases = new ArrayList<>();
        cases.add(new TestCase(
                "qs-case-1",
                "经典乱序",
                "常见教学示例，包含重复与跨度较大的数值。",
                Map.of("array", List.of(38, 27, 43, 3, 9, 82, 10))
        ));
        cases.add(new TestCase(
                "qs-case-2",
                "近乎有序",
                "仅末尾两个元素需要交换，便于观察分区过程。",
                Map.of("array", List.of(1, 2, 3, 4, 5, 3, 7))
        ));
        return cases;
    }

    @Override
    protected void buildSteps(Map<String, Object> input) {
        int[] array = toIntArray(input.get("array"));
        this.inputSize = array.length;
        if (array.length == 0) {
            throw new IllegalArgumentException("数组不能为空");
        }
        if (array.length > 30) {
            throw new IllegalArgumentException("数组长度不能超过 30");
        }

        addStep("初始化：准备对数组执行快速排序", snapshot(array, -1, -1, -1, List.of()));
        quickSort(array, 0, array.length - 1);
        addStep("排序完成：所有元素已按升序排列", snapshot(array, -1, -1, -1, List.of()));
    }

    @Override
    protected int getInputSize() {
        return inputSize;
    }

    private void quickSort(int[] array, int low, int high) {
        if (low >= high) {
            return;
        }

        int pivotIndex = high;
        int pivotValue = array[pivotIndex];
        addStep("选择基准 pivot = arr[" + pivotIndex + "] = " + pivotValue,
                snapshot(array, pivotIndex, low, high, List.of(pivotIndex)));

        int storeIndex = low;
        for (int i = low; i < high; i++) {
            addStep("比较 arr[" + i + "]=" + array[i] + " 与 pivot=" + pivotValue,
                    snapshot(array, pivotIndex, i, high, List.of(pivotIndex, i)));

            if (array[i] < pivotValue) {
                if (i != storeIndex) {
                    swap(array, i, storeIndex);
                    addStep("交换 arr[" + i + "] 与 arr[" + storeIndex + "]，将较小元素放到左侧",
                            snapshot(array, pivotIndex, i, storeIndex, List.of(pivotIndex, i, storeIndex)));
                } else {
                    addStep("arr[" + i + "] 已在正确位置，无需交换",
                            snapshot(array, pivotIndex, i, storeIndex, List.of(pivotIndex, i, storeIndex)));
                }
                storeIndex++;
            }
        }

        if (storeIndex != pivotIndex) {
            swap(array, storeIndex, pivotIndex);
            addStep("将 pivot 放到分区边界 arr[" + storeIndex + "]",
                    snapshot(array, storeIndex, low, high, List.of(storeIndex)));
        } else {
            addStep("pivot 已在正确位置 arr[" + storeIndex + "]",
                    snapshot(array, storeIndex, low, high, List.of(storeIndex)));
        }

        quickSort(array, low, storeIndex - 1);
        quickSort(array, storeIndex + 1, high);
    }

    private void swap(int[] array, int i, int j) {
        int temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }

    private Map<String, Object> snapshot(int[] array, int pivot, int active, int secondary, List<Integer> highlights) {
        Map<String, Object> map = new HashMap<>();
        map.put("array", toList(array));
        map.put("pivot", pivot);
        map.put("active", active);
        map.put("secondary", secondary);
        map.put("highlights", highlights);
        return map;
    }

    public static Map<String, Object> randomInput() {
        Random random = new Random();
        int size = 6 + random.nextInt(7);
        List<Integer> values = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            values.add(1 + random.nextInt(99));
        }
        return Map.of("array", values);
    }

    private int[] toIntArray(Object raw) {
        if (raw instanceof List<?> list) {
            int[] array = new int[list.size()];
            for (int i = 0; i < list.size(); i++) {
                array[i] = ((Number) list.get(i)).intValue();
            }
            return array;
        }
        throw new IllegalArgumentException("array 字段必须是整数数组");
    }

    private List<Integer> toList(int[] array) {
        List<Integer> list = new ArrayList<>();
        for (int value : array) {
            list.add(value);
        }
        return list;
    }
}
