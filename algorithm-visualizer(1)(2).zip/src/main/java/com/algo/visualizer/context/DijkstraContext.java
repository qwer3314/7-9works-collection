package com.algo.visualizer.context;

import com.algo.visualizer.model.AlgorithmInfo;
import com.algo.visualizer.model.TestCase;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Random;

public class DijkstraContext extends AbstractAlgorithmContext {

    public DijkstraContext() {
        super(new AlgorithmInfo(
                "dijkstra",
                "Dijkstra 最短路径",
                "图算法",
                "中",
                "从源点出发，每次选择当前距离最小的未确定节点，松弛其所有出边，直到找到目标最短路径。",
                "O((V + E) log V)",
                "O(V)",
                "JSON 图结构：nodes、edges、source、target"
        ));
    }

    @Override
    public List<TestCase> getTestCases() {
        List<TestCase> cases = new ArrayList<>();
        cases.add(new TestCase(
                "dk-case-1",
                "五节点教学图",
                "经典带权有向图，适合展示松弛过程。",
                Map.of(
                        "nodes", List.of("A", "B", "C", "D", "E"),
                        "edges", List.of(
                                edge("A", "B", 6),
                                edge("A", "C", 1),
                                edge("C", "B", 2),
                                edge("C", "D", 2),
                                edge("B", "D", 3),
                                edge("B", "E", 5),
                                edge("D", "E", 2)
                        ),
                        "source", "A",
                        "target", "E"
                )
        ));
        cases.add(new TestCase(
                "dk-case-2",
                "存在绕路更优",
                "直接边权重较大，需经过中间节点得到更短路径。",
                Map.of(
                        "nodes", List.of("S", "M", "T"),
                        "edges", List.of(
                                edge("S", "T", 10),
                                edge("S", "M", 1),
                                edge("M", "T", 2)
                        ),
                        "source", "S",
                        "target", "T"
                )
        ));
        return cases;
    }

    @Override
    protected void buildSteps(Map<String, Object> input) {
        Graph graph = Graph.fromInput(input);
        Map<String, Integer> dist = new HashMap<>();
        Map<String, String> prev = new HashMap<>();
        PriorityQueue<NodeDist> queue = new PriorityQueue<>();

        for (String node : graph.nodes) {
            dist.put(node, Integer.MAX_VALUE);
        }
        dist.put(graph.source, 0);
        queue.add(new NodeDist(graph.source, 0));

        addStep("初始化：源点 " + graph.source + " 距离设为 0，其余节点设为无穷大",
                graphSnapshot(graph, dist, prev, List.of(graph.source), graph.source, null, List.of()));

        while (!queue.isEmpty()) {
            NodeDist current = queue.poll();
            String u = current.node;
            if (current.distance > dist.get(u)) {
                continue;
            }

            List<String> settled = new ArrayList<>();
            for (String node : graph.nodes) {
                if (dist.get(node) < Integer.MAX_VALUE) {
                    settled.add(node);
                }
            }

            addStep("确定节点 " + u + " 的最短距离为 " + dist.get(u),
                    graphSnapshot(graph, dist, prev, settled, u, null, pathTo(graph, prev, graph.source, u)));

            if (u.equals(graph.target)) {
                break;
            }

            for (Edge edge : graph.edgesFrom(u)) {
                String v = edge.to;
                int alt = dist.get(u) + edge.weight;
                addStep("尝试松弛边 " + u + " → " + v + "，候选距离 = " + alt,
                        graphSnapshot(graph, dist, prev, settled, u, edge, pathTo(graph, prev, graph.source, u)));

                if (alt < dist.get(v)) {
                    dist.put(v, alt);
                    prev.put(v, u);
                    queue.add(new NodeDist(v, alt));
                    addStep("更新 dist[" + v + "] = " + alt + "，前驱为 " + u,
                            graphSnapshot(graph, dist, prev, settled, u, edge, pathTo(graph, prev, graph.source, v)));
                } else {
                    addStep("无需更新：当前 dist[" + v + "] = " + formatDist(dist.get(v)) + " 更优",
                            graphSnapshot(graph, dist, prev, settled, u, edge, pathTo(graph, prev, graph.source, v)));
                }
            }
        }

        List<String> finalPath = pathTo(graph, prev, graph.source, graph.target);
        addStep("完成：到 " + graph.target + " 的最短距离为 " + formatDist(dist.get(graph.target))
                        + "，路径为 " + String.join(" → ", finalPath),
                graphSnapshot(graph, dist, prev, graph.nodes, graph.target, null, finalPath));
    }

    private static Map<String, Object> edge(String from, String to, int weight) {
        Map<String, Object> edge = new HashMap<>();
        edge.put("from", from);
        edge.put("to", to);
        edge.put("weight", weight);
        return edge;
    }

    private Map<String, Object> graphSnapshot(Graph graph, Map<String, Integer> dist, Map<String, String> prev,
                                              List<String> settled, String active, Edge activeEdge, List<String> path) {
        Map<String, Object> map = new HashMap<>();
        map.put("nodes", graph.nodes);
        map.put("edges", graph.edgeMaps());
        map.put("distances", formatDistances(graph.nodes, dist));
        map.put("predecessors", prev);
        map.put("settled", settled);
        map.put("active", active);
        map.put("activeEdge", activeEdge == null ? null : activeEdge.toMap());
        map.put("source", graph.source);
        map.put("target", graph.target);
        map.put("path", path);
        return map;
    }

    private List<String> pathTo(Graph graph, Map<String, String> prev, String source, String target) {
        List<String> path = new ArrayList<>();
        String current = target;
        while (current != null) {
            path.add(0, current);
            if (current.equals(source)) {
                break;
            }
            current = prev.get(current);
        }
        if (path.isEmpty() || !path.get(0).equals(source)) {
            return List.of(source);
        }
        return path;
    }

    private Map<String, Object> formatDistances(List<String> nodes, Map<String, Integer> dist) {
        Map<String, Object> display = new HashMap<>();
        for (String node : nodes) {
            int value = dist.get(node);
            display.put(node, value == Integer.MAX_VALUE ? "∞" : value);
        }
        return display;
    }

    private String formatDist(int value) {
        return value == Integer.MAX_VALUE ? "∞" : String.valueOf(value);
    }

    public static Map<String, Object> randomInput() {
        Random random = new Random();
        List<String> nodes = List.of("N1", "N2", "N3", "N4");
        List<Map<String, Object>> edges = new ArrayList<>();
        edges.add(edge("N1", "N2", 2 + random.nextInt(5)));
        edges.add(edge("N1", "N3", 1 + random.nextInt(4)));
        edges.add(edge("N2", "N4", 1 + random.nextInt(6)));
        edges.add(edge("N3", "N2", 1 + random.nextInt(3)));
        edges.add(edge("N3", "N4", 3 + random.nextInt(4)));
        Map<String, Object> data = new HashMap<>();
        data.put("nodes", nodes);
        data.put("edges", edges);
        data.put("source", "N1");
        data.put("target", "N4");
        return data;
    }

    private static class Graph {
        private final List<String> nodes;
        private final List<Edge> edges;
        private final String source;
        private final String target;

        private Graph(List<String> nodes, List<Edge> edges, String source, String target) {
            this.nodes = nodes;
            this.edges = edges;
            this.source = source;
            this.target = target;
        }

        static Graph fromInput(Map<String, Object> input) {
            Object nodesRaw = input.get("nodes");
            Object edgesRaw = input.get("edges");
            if (!(nodesRaw instanceof List<?> nodeList) || nodeList.isEmpty()) {
                throw new IllegalArgumentException("nodes 不能为空");
            }
            if (!(edgesRaw instanceof List<?> edgeList) || edgeList.isEmpty()) {
                throw new IllegalArgumentException("edges 不能为空");
            }

            List<String> nodes = new ArrayList<>();
            for (Object node : nodeList) {
                nodes.add(String.valueOf(node));
            }

            List<Edge> edges = new ArrayList<>();
            for (Object item : edgeList) {
                if (!(item instanceof Map<?, ?> map)) {
                    throw new IllegalArgumentException("edges 格式错误");
                }
                String from = String.valueOf(map.get("from"));
                String to = String.valueOf(map.get("to"));
                int weight = ((Number) map.get("weight")).intValue();
                edges.add(new Edge(from, to, weight));
            }

            String source = String.valueOf(input.getOrDefault("source", nodes.get(0)));
            String target = String.valueOf(input.getOrDefault("target", nodes.get(nodes.size() - 1)));
            if (!nodes.contains(source) || !nodes.contains(target)) {
                throw new IllegalArgumentException("source 或 target 不在节点列表中");
            }
            return new Graph(nodes, edges, source, target);
        }

        List<Edge> edgesFrom(String node) {
            List<Edge> result = new ArrayList<>();
            for (Edge edge : edges) {
                if (edge.from.equals(node)) {
                    result.add(edge);
                }
            }
            return result;
        }

        List<Map<String, Object>> edgeMaps() {
            List<Map<String, Object>> maps = new ArrayList<>();
            for (Edge edge : edges) {
                maps.add(edge.toMap());
            }
            return maps;
        }
    }

    private static class Edge {
        private final String from;
        private final String to;
        private final int weight;

        private Edge(String from, String to, int weight) {
            this.from = from;
            this.to = to;
            this.weight = weight;
        }

        Map<String, Object> toMap() {
            Map<String, Object> map = new HashMap<>();
            map.put("from", from);
            map.put("to", to);
            map.put("weight", weight);
            return map;
        }
    }

    private static class NodeDist implements Comparable<NodeDist> {
        private final String node;
        private final int distance;

        private NodeDist(String node, int distance) {
            this.node = node;
            this.distance = distance;
        }

        @Override
        public int compareTo(NodeDist other) {
            return Integer.compare(this.distance, other.distance);
        }
    }
}
