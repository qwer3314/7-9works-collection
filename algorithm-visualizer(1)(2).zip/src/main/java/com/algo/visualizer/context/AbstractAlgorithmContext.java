package com.algo.visualizer.context;

import com.algo.visualizer.model.AlgorithmInfo;
import com.algo.visualizer.model.StepSnapshot;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public abstract class AbstractAlgorithmContext implements AlgorithmContext {

    protected final AlgorithmInfo info;
    protected final List<StepSnapshot> steps = new ArrayList<>();
    protected int currentStep = -1;
    protected boolean initialized;

    protected AbstractAlgorithmContext(AlgorithmInfo info) {
        this.info = info;
    }

    @Override
    public String getId() {
        return info.getId();
    }

    @Override
    public AlgorithmInfo getInfo() {
        return info;
    }

    @Override
    public void initialize(Map<String, Object> input) {
        steps.clear();
        currentStep = -1;
        initialized = true;
        buildSteps(input);
        for (int i = 0; i < steps.size(); i++) {
            StepSnapshot step = steps.get(i);
            step.setStepIndex(i);
            step.setTotalSteps(steps.size());
            step.copyMetaFrom(info);
            if (i == steps.size() - 1) {
                step.setFinished(true);
            }
        }
    }

    protected abstract void buildSteps(Map<String, Object> input);

    protected StepSnapshot addStep(String log, Map<String, Object> snapshot) {
        StepSnapshot step = new StepSnapshot();
        step.setLog(log);
        step.setSnapshot(snapshot);
        steps.add(step);
        return step;
    }

    @Override
    public StepSnapshot step() {
        if (!initialized || steps.isEmpty()) {
            throw new IllegalStateException("Algorithm not initialized");
        }
        if (currentStep + 1 >= steps.size()) {
            StepSnapshot last = steps.get(steps.size() - 1);
            last.setFinished(true);
            if (last.getActualTimeComplexity() == null) {
                calculateActualComplexity(last);
            }
            return last;
        }
        currentStep++;
        StepSnapshot current = steps.get(currentStep);
        if (currentStep == steps.size() - 1) {
            current.setFinished(true);
            calculateActualComplexity(current);
        }
        return current;
    }

    protected void calculateActualComplexity(StepSnapshot last) {
        int n = getInputSize();
        int actualSteps = steps.size();
        
        String actualTime = estimateTimeComplexity(n, actualSteps);
        String actualSpace = estimateSpaceComplexity();
        
        last.setActualTimeComplexity(actualTime);
        last.setActualSpaceComplexity(actualSpace);
    }

    protected int getInputSize() {
        return 0;
    }

    protected String estimateTimeComplexity(int n, int steps) {
        if (n <= 0 || steps <= 0) return "O(1)";
        
        if (n == 1) return "O(1)";
        
        double nSquared = n * n;
        double ratio = (double) steps / nSquared;
        
        if (ratio < 0.4) return "O(n)";
        if (ratio < 0.7) return "O(n log n)";
        return "O(n²)";
    }

    protected String estimateSpaceComplexity() {
        return info.getSpaceComplexity();
    }

    @Override
    public StepSnapshot prev() {
        if (!initialized || steps.isEmpty()) {
            throw new IllegalStateException("Algorithm not initialized");
        }
        if (currentStep <= 0) {
            currentStep = -1;
            StepSnapshot snapshot = new StepSnapshot();
            snapshot.setCode(200);
            snapshot.setLog("已回退到初始状态");
            snapshot.copyMetaFrom(info);
            snapshot.setFinished(false);
            snapshot.setStepIndex(-1);
            snapshot.setTotalSteps(steps.size());
            if (!steps.isEmpty()) {
                snapshot.setSnapshot(steps.get(0).getSnapshot());
            }
            return snapshot;
        }
        currentStep--;
        StepSnapshot snapshot = steps.get(currentStep);
        snapshot.setFinished(false);
        return snapshot;
    }

    @Override
    public StepSnapshot getCurrentSnapshot() {
        if (!initialized || steps.isEmpty()) {
            return null;
        }
        if (currentStep < 0) {
            return null;
        }
        return steps.get(currentStep);
    }

    @Override
    public void reset() {
        currentStep = -1;
    }

    @Override
    public boolean isInitialized() {
        return initialized;
    }

    @Override
    public boolean isFinished() {
        return initialized && !steps.isEmpty() && currentStep >= steps.size() - 1;
    }

    @Override
    public List<String> getLogs() {
        return steps.stream()
                .map(StepSnapshot::getLog)
                .toList();
    }
}
