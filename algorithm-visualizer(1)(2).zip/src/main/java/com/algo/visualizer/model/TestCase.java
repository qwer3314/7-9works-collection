package com.algo.visualizer.model;

import java.util.Map;

public class TestCase {

    private String id;
    private String name;
    private String description;
    private Map<String, Object> data;

    public TestCase() {
    }

    public TestCase(String id, String name, String description, Map<String, Object> data) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.data = data;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Map<String, Object> getData() {
        return data;
    }

    public void setData(Map<String, Object> data) {
        this.data = data;
    }
}
