package com.algo.visualizer.model;

import java.util.Map;

public class InitRequest {

    private String caseId;
    private Map<String, Object> data;

    public String getCaseId() {
        return caseId;
    }

    public void setCaseId(String caseId) {
        this.caseId = caseId;
    }

    public Map<String, Object> getData() {
        return data;
    }

    public void setData(Map<String, Object> data) {
        this.data = data;
    }
}
