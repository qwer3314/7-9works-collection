package com.algo.visualizer.model;

import java.util.HashMap;
import java.util.Map;

public class StepSnapshot {

    private int code = 200;
    private boolean finished;
    private int stepIndex;
    private int totalSteps;
    private String log;
    private String timeComplexity;
    private String spaceComplexity;
    private String actualTimeComplexity;
    private String actualSpaceComplexity;
    private Map<String, Object> snapshot = new HashMap<>();

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public boolean isFinished() {
        return finished;
    }

    public void setFinished(boolean finished) {
        this.finished = finished;
    }

    public int getStepIndex() {
        return stepIndex;
    }

    public void setStepIndex(int stepIndex) {
        this.stepIndex = stepIndex;
    }

    public int getTotalSteps() {
        return totalSteps;
    }

    public void setTotalSteps(int totalSteps) {
        this.totalSteps = totalSteps;
    }

    public String getLog() {
        return log;
    }

    public void setLog(String log) {
        this.log = log;
    }

    public String getTimeComplexity() {
        return timeComplexity;
    }

    public void setTimeComplexity(String timeComplexity) {
        this.timeComplexity = timeComplexity;
    }

    public String getSpaceComplexity() {
        return spaceComplexity;
    }

    public void setSpaceComplexity(String spaceComplexity) {
        this.spaceComplexity = spaceComplexity;
    }

    public String getActualTimeComplexity() {
        return actualTimeComplexity;
    }

    public void setActualTimeComplexity(String actualTimeComplexity) {
        this.actualTimeComplexity = actualTimeComplexity;
    }

    public String getActualSpaceComplexity() {
        return actualSpaceComplexity;
    }

    public void setActualSpaceComplexity(String actualSpaceComplexity) {
        this.actualSpaceComplexity = actualSpaceComplexity;
    }

    public Map<String, Object> getSnapshot() {
        return snapshot;
    }

    public void setSnapshot(Map<String, Object> snapshot) {
        this.snapshot = snapshot;
    }

    public StepSnapshot copyMetaFrom(AlgorithmInfo info) {
        this.timeComplexity = info.getTimeComplexity();
        this.spaceComplexity = info.getSpaceComplexity();
        return this;
    }
}
