package com.algo.visualizer.model;

import java.util.Map;

public class AlgorithmInfo {

    private String id;
    private String name;
    private String category;
    private String difficulty;
    private String description;
    private String timeComplexity;
    private String spaceComplexity;
    private String inputHint;

    public AlgorithmInfo() {
    }

    public AlgorithmInfo(String id, String name, String category, String difficulty, String description,
                       String timeComplexity, String spaceComplexity, String inputHint) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.difficulty = difficulty;
        this.description = description;
        this.timeComplexity = timeComplexity;
        this.spaceComplexity = spaceComplexity;
        this.inputHint = inputHint;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getDifficulty() {
        return difficulty;
    }

    public void setDifficulty(String difficulty) {
        this.difficulty = difficulty;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTimeComplexity() {
        return timeComplexity;
    }

    public void setTimeComplexity(String timeComplexity) {
        this.timeComplexity = timeComplexity;
    }

    public String getSpaceComplexity() {
        return spaceComplexity;
    }

    public void setSpaceComplexity(String spaceComplexity) {
        this.spaceComplexity = spaceComplexity;
    }

    public String getInputHint() {
        return inputHint;
    }

    public void setInputHint(String inputHint) {
        this.inputHint = inputHint;
    }
}
