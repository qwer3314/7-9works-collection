package com.algo.visualizer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlgoVisualizerApplication {

    public static void main(String[] args) {
        SpringApplication.run(AlgoVisualizerApplication.class, args);
    }
}
