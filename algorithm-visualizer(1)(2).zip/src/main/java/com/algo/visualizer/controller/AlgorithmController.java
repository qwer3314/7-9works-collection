package com.algo.visualizer.controller;

import com.algo.visualizer.model.ApiResponse;
import com.algo.visualizer.model.InitRequest;
import com.algo.visualizer.model.StepSnapshot;
import com.algo.visualizer.service.AlgorithmService;
import jakarta.servlet.http.HttpSession;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class AlgorithmController {

    private final AlgorithmService algorithmService;

    public AlgorithmController(AlgorithmService algorithmService) {
        this.algorithmService = algorithmService;
    }

    @GetMapping("/algorithms")
    public ApiResponse listAlgorithms() {
        return ApiResponse.ok("success", algorithmService.listAlgorithms());
    }

    @GetMapping("/{algo}/info")
    public ApiResponse info(@PathVariable String algo) {
        return ApiResponse.ok("success", algorithmService.getInfo(algo));
    }

    @GetMapping("/{algo}/cases")
    public ApiResponse cases(@PathVariable String algo) {
        return ApiResponse.ok("success", algorithmService.getTestCases(algo));
    }

    @GetMapping("/{algo}/random")
    public ApiResponse random(@PathVariable String algo) {
        return ApiResponse.ok("success", algorithmService.randomInput(algo));
    }

    @PostMapping("/{algo}/init")
    public StepSnapshot init(@PathVariable String algo, @RequestBody InitRequest request, HttpSession session) {
        return algorithmService.init(algo, request, session);
    }

    @PostMapping("/{algo}/step")
    public StepSnapshot step(@PathVariable String algo, HttpSession session) {
        return algorithmService.step(algo, session);
    }

    @PostMapping("/{algo}/prev")
    public StepSnapshot prev(@PathVariable String algo, HttpSession session) {
        return algorithmService.prev(algo, session);
    }

    @GetMapping("/{algo}/reset")
    public StepSnapshot reset(@PathVariable String algo, HttpSession session) {
        return algorithmService.reset(algo, session);
    }

    @GetMapping("/{algo}/export")
    public ApiResponse exportLogs(@PathVariable String algo, HttpSession session) {
        return ApiResponse.ok("success", algorithmService.exportLogs(algo, session));
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ApiResponse handleBadRequest(IllegalArgumentException ex) {
        return ApiResponse.error(ex.getMessage());
    }

    @ExceptionHandler(IllegalStateException.class)
    public ApiResponse handleBadState(IllegalStateException ex) {
        return ApiResponse.error(ex.getMessage());
    }
}
