package com.algo.visualizer.service;

import com.algo.visualizer.context.AlgorithmContext;
import com.algo.visualizer.context.BubbleSortContext;
import com.algo.visualizer.context.DijkstraContext;
import com.algo.visualizer.context.HanoiContext;
import com.algo.visualizer.context.HuffmanContext;
import com.algo.visualizer.context.QuickSortContext;
import com.algo.visualizer.model.AlgorithmInfo;
import com.algo.visualizer.model.InitRequest;
import com.algo.visualizer.model.StepSnapshot;
import com.algo.visualizer.model.TestCase;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class AlgorithmService {

    private static final String SESSION_PREFIX = "algo-context-";

    private final Map<String, AlgorithmContext> prototypes = new LinkedHashMap<>();

    public AlgorithmService() {
        register(new QuickSortContext());
        register(new BubbleSortContext());
        register(new DijkstraContext());
        register(new HanoiContext());
        register(new HuffmanContext());
    }

    private void register(AlgorithmContext context) {
        prototypes.put(context.getId(), context);
    }

    public List<AlgorithmInfo> listAlgorithms() {
        return prototypes.values().stream().map(AlgorithmContext::getInfo).toList();
    }

    public AlgorithmInfo getInfo(String algoId) {
        AlgorithmContext prototype = getPrototype(algoId);
        return prototype.getInfo();
    }

    public List<TestCase> getTestCases(String algoId) {
        return getPrototype(algoId).getTestCases();
    }

    public StepSnapshot init(String algoId, InitRequest request, HttpSession session) {
        AlgorithmContext context = createContext(algoId);
        Map<String, Object> input = resolveInput(algoId, request);
        context.initialize(input);
        session.setAttribute(sessionKey(algoId), context);
        context.reset();
        return context.step();
    }

    public StepSnapshot step(String algoId, HttpSession session) {
        AlgorithmContext context = getSessionContext(algoId, session);
        return context.step();
    }

    public StepSnapshot prev(String algoId, HttpSession session) {
        AlgorithmContext context = getSessionContext(algoId, session);
        return context.prev();
    }

    public List<String> exportLogs(String algoId, HttpSession session) {
        AlgorithmContext context = getSessionContext(algoId, session);
        return context.getLogs();
    }

    public StepSnapshot reset(String algoId, HttpSession session) {
        AlgorithmContext context = getSessionContext(algoId, session);
        context.reset();
        StepSnapshot snapshot = new StepSnapshot();
        snapshot.setCode(200);
        snapshot.setLog("已重置到初始状态，请再次点击单步执行");
        snapshot.copyMetaFrom(context.getInfo());
        snapshot.setFinished(false);
        snapshot.setStepIndex(0);
        snapshot.setTotalSteps(context.getCurrentSnapshot() == null ? 0 : context.getCurrentSnapshot().getTotalSteps());
        return snapshot;
    }

    public Map<String, Object> randomInput(String algoId) {
        return switch (algoId) {
            case "quicksort" -> QuickSortContext.randomInput();
            case "bubblesort" -> BubbleSortContext.randomInput();
            case "dijkstra" -> DijkstraContext.randomInput();
            case "hanoi" -> HanoiContext.randomInput();
            case "huffman" -> HuffmanContext.randomInput();
            default -> throw new IllegalArgumentException("未知算法: " + algoId);
        };
    }

    private Map<String, Object> resolveInput(String algoId, InitRequest request) {
        if (request.getCaseId() != null && !request.getCaseId().isBlank()) {
            return getPrototype(algoId).getTestCases().stream()
                    .filter(testCase -> testCase.getId().equals(request.getCaseId()))
                    .findFirst()
                    .map(TestCase::getData)
                    .orElseThrow(() -> new IllegalArgumentException("未找到测试用例: " + request.getCaseId()));
        }
        if (request.getData() != null && !request.getData().isEmpty()) {
            return request.getData();
        }
        throw new IllegalArgumentException("请提供 data 或 caseId");
    }

    private AlgorithmContext createContext(String algoId) {
        AlgorithmContext prototype = getPrototype(algoId);
        return switch (algoId) {
            case "quicksort" -> new QuickSortContext();
            case "bubblesort" -> new BubbleSortContext();
            case "dijkstra" -> new DijkstraContext();
            case "hanoi" -> new HanoiContext();
            case "huffman" -> new HuffmanContext();
            default -> throw new IllegalArgumentException("未知算法: " + algoId);
        };
    }

    private AlgorithmContext getPrototype(String algoId) {
        AlgorithmContext context = prototypes.get(algoId);
        if (context == null) {
            throw new IllegalArgumentException("未知算法: " + algoId);
        }
        return context;
    }

    private AlgorithmContext getSessionContext(String algoId, HttpSession session) {
        AlgorithmContext context = (AlgorithmContext) session.getAttribute(sessionKey(algoId));
        if (context == null || !context.isInitialized()) {
            throw new IllegalStateException("请先初始化算法数据");
        }
        return context;
    }

    private String sessionKey(String algoId) {
        return SESSION_PREFIX + algoId;
    }
}
