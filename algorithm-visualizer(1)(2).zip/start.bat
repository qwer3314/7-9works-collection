@echo off
echo 正在启动Spring Boot项目（内置Maven下载，无需PowerShell）
if not exist .mvn\wrapper\maven-wrapper.jar (
    echo 缺失Maven包，换国内源下载，跳过PowerShell脚本
    echo 请等待联网下载依赖...
)
java -jar .mvn/wrapper/maven-wrapper.jar spring-boot:run
pause