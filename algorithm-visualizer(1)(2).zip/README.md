# 算法过程可视化系统

基于 **Java Web（Spring Boot）+ HTML5 Canvas** 的 B/S 架构算法过程可视化实验平台。系统通过 HttpSession 保存每个用户的算法执行上下文，每次请求仅推进一个原子步骤，前端根据后端返回的 JSON 状态重新渲染 Canvas。

## 功能概览

- 4 种算法统一入口：快速排序、Dijkstra 最短路径、汉诺塔、哈夫曼树构造
- 手动输入、随机生成、预设测试用例（每算法 2 条，共 8 条）
- 单步执行、连续执行、暂停、重置
- 图形 + 步骤日志 + 时间/空间复杂度说明
- 多用户 Session 隔离

## 环境要求

- JDK 17+
- 浏览器：Chrome / Edge / Firefox 现代版本
- 无需单独安装 Maven（项目自带 `mvnw.cmd`）

## 运行方式

```bash
cd algorithm-visualizer
mvnw.cmd spring-boot:run
```

启动后访问：

```
http://localhost:8080
```

## 使用说明

1. 在首页顶部选择算法卡片
2. 在左侧输入测试数据，或点击“随机生成 / 预设用例”
3. 点击“初始化”
4. 使用“单步执行”或“连续执行”观察过程
5. 点击“重置”后可重新初始化

## 输入格式

### 快速排序 `quicksort`

```
38,27,43,3,9,82,10
```

### Dijkstra `dijkstra`

```json
{
  "nodes": ["A", "B", "C", "D", "E"],
  "edges": [
    {"from": "A", "to": "B", "weight": 6},
    {"from": "A", "to": "C", "weight": 1},
    {"from": "C", "to": "B", "weight": 2},
    {"from": "C", "to": "D", "weight": 2},
    {"from": "B", "to": "D", "weight": 3},
    {"from": "B", "to": "E", "weight": 5},
    {"from": "D", "to": "E", "weight": 2}
  ],
  "source": "A",
  "target": "E"
}
```

### 汉诺塔 `hanoi`

```
3
```

表示 3 个盘子，范围 3-8。

### 哈夫曼树 `huffman`

```
A:5,B:9,C:12,D:13,E:16,F:45
```

## API 接口

| 接口 | 方法 | 说明 |
|------|------|------|
| `/api/algorithms` | GET | 算法列表 |
| `/api/{algo}/info` | GET | 算法说明 |
| `/api/{algo}/cases` | GET | 预设测试用例 |
| `/api/{algo}/random` | GET | 随机测试数据 |
| `/api/{algo}/init` | POST | 初始化算法 |
| `/api/{algo}/step` | POST | 前进一步 |
| `/api/{algo}/reset` | GET | 重置进度 |

## 测试方式

1. 启动系统后逐一点击 4 个算法的预设用例
2. 初始化后连续点击“单步执行”，确认画布与日志同步变化
3. 点击“连续执行”，调节速度滑块，确认动画流畅
4. 执行结束后状态显示“已完成”
5. 点击“重置”后重新初始化，确认 Session 状态恢复

## 项目结构

```
src/main/java/com/algo/visualizer/
├── controller/     # REST 接口
├── service/        # 业务调度
├── context/        # 各算法状态机
└── model/          # DTO
src/main/resources/static/
├── index.html
├── css/style.css
└── js/
    ├── app.js
    └── renderers.js
```

## 课设对应关系

- 至少 3 类算法：排序 / 图 / 递归 / 树结构
- 中等及以上难度：Dijkstra、汉诺塔
- 统一入口与界面风格
- 手动输入 + 随机生成 + 预设用例
- 分步可视化，不仅展示最终结果
- 展示步骤说明与复杂度
- 单步 / 连续 / 暂停 / 重置

## 常见问题

**Q: 首次运行下载依赖较慢？**  
A: Maven Wrapper 会自动下载 Maven 和依赖，请保持网络畅通。

**Q: 提示“请先初始化算法数据”？**  
A: 需要先点击“初始化”或预设用例，再执行单步/连续。

**Q: 端口被占用？**  
A: 修改 `src/main/resources/application.properties` 中的 `server.port`。
