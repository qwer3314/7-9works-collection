@echo off
setlocal
cd /d %~dp0

if not exist ".mvn\wrapper\maven-wrapper.jar" (
  echo Downloading Maven Wrapper...
  powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://repo.maven.apache.org/maven2/org/apache/maven/wrapper/maven-wrapper/3.2.0/maven-wrapper-3.2.0.jar' -OutFile '.mvn\wrapper\maven-wrapper.jar'"
)

echo Starting algorithm visualizer...
call mvnw.cmd spring-boot:run
pause